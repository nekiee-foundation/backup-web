# instapayment
A demo frame for payment API using InstaMojo

Demo URL : http://demo.coregenie.com/instamojo/
