<?php 
session_start();
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 'On');  //On or Off
include('../php/connect.php');

if(!isset($_SESSION["Username"]) || !isset($_SESSION["Password"])){    
  header("location:login.php");
  die();
}

if(isset($_SESSION["Username"]) && isset($_SESSION["Password"])){
    $result = $con->prepare("SELECT * FROM users WHERE user_id ='".$_SESSION["Username"]."' ");
    $result->execute();
    $row = $result->fetch();

    $product_name = $_POST["camp_id"];
    $price = $_POST["donation_amt"];
    $name = $row['name'];
    $email = $row['email'];

    include 'src/instamojo.php';

    $api = new Instamojo\Instamojo('e25b7805aadebcbef3273f60eea4fdb4', '00c0350798c1c0f7696fb7f6bd91a9d7','https://test.instamojo.com/api/1.1/');   

try {
    $response = $api->paymentRequestCreate(array(
        "purpose" => $product_name,
        "amount" => $price,
        "buyer_name" => $name,
        "send_email" => true,
        "send_sms" => false,
        "email" => $email,

        'allow_repeated_payments' => false,
        "redirect_url" => "https://neikee.com/test/thankyou.php",
        "webhook" => "https://neikee.com/test/webhook.php"
        ));
    //print_r($response);

    $pay_ulr = $response['longurl'];
    
    //Redirect($response['longurl'],302); //Go to Payment page          
            


    header("Location: $pay_ulr");
    exit();

}
catch (Exception $e) {
    print('Error: ' . $e->getMessage());
}      
}


  ?>
