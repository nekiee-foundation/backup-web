<?php
session_start();
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 'On');  //On or Off
include('php/connect.php');

if(isset($_SESSION["Username"]) && isset($_SESSION["Password"])){
  $Username=$_SESSION["Username"];
  $result = $con->prepare("SELECT * FROM users WHERE user_id ='".$Username."' ");
  $result->execute();
  $row = $result->fetch();
}

  $camp_list = $con->prepare("SELECT * FROM campaign");
  $camp_list->execute();



?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
  <meta name="description" content="Neikee" />
  <meta name="keywords" content="funding,Crowdfunding,NGO,social,social cause,Neikee" />
  <meta name="author" content="Kodexlabs" />

  <!-- Page Title -->
  <title>Neikee - Charity & Crowdfunding Neikee</title>

  <!-- Favicon and Touch Icons -->
  <link href="images/favicon.png" rel="shortcut icon" type="image/png">
  <link href="images/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="images/apple-touch-icon-72x72.png" rel="apple-touch-icon" sizes="72x72">
  <link href="images/apple-touch-icon-114x114.png" rel="apple-touch-icon" sizes="114x114">
  <link href="images/apple-touch-icon-144x144.png" rel="apple-touch-icon" sizes="144x144">

  <!-- Stylesheet -->
  <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
  <link href="css/animate.css" rel="stylesheet" type="text/css">
  <link href="css/css-plugin-collections.css" rel="stylesheet"/>
  <!-- CSS | menuzord megamenu skins -->
  <link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-boxed.css" rel="stylesheet"/>
  <!-- CSS | Main style file -->
  <link href="css/style-main.css" rel="stylesheet" type="text/css">
  <!-- CSS | Preloader Styles -->
  <link href="css/preloader.css" rel="stylesheet" type="text/css">
  <!-- CSS | Custom Margin Padding Collection -->
  <link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
  <!-- CSS | Responsive media queries -->
  <link href="css/responsive.css" rel="stylesheet" type="text/css">
  <!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
  <!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

  <!-- Revolution Slider 5.x CSS settings -->
  <link  href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
  <link  href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
  <link  href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>

  <!-- CSS | Theme Color -->
  <link href="css/colors/theme-skin-yellow.css" rel="stylesheet" type="text/css">

  <!-- external javascripts -->
  <script src="js/jquery-2.2.0.min.js"></script>
  <script src="js/jquery-ui.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <!-- JS | jquery plugin collection for this theme -->
  <script src="js/jquery-plugin-collection.js"></script>

  <!-- Revolution Slider 5.x SCRIPTS -->
  <script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
  <script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="has-side-panel side-panel-right fullwidth-page side-push-panel">
  <div class="body-overlay"></div>
  <div id="side-panel" class="dark" data-bg-img="http://placehold.it/1920x1280">
    <div class="side-panel-wrap">
      <div id="side-panel-trigger-close" class="side-panel-trigger"><a href="#"><i class="icon_close font-30"></i></a></div>
      <a href="javascript:void(0)"><img alt="logo" src="images/logo-wide.png"></a>
      <div class="side-panel-nav mt-30">
        <div class="widget no-border">
          <nav>
            <ul class="nav nav-list">
              <li><a href="#">Home</a></li>
              <li><a href="#">Services</a></li>
              <li><a class="tree-toggler nav-header">Pages <i class="fa fa-angle-down"></i></a>
                <ul class="nav nav-list tree">
                  <li><a href="#">About</a></li>
                  <li><a href="#">Terms</a></li>
                  <li><a href="#">FAQ</a></li>
                </ul>
              </li>
              <li><a href="#">Contact</a></li>
            </ul>
          </nav>        
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="side-panel-widget mt-30">
        <div class="widget no-border">
          <ul>
            <li class="font-14 mb-5"> <i class="fa fa-phone text-theme-colored"></i> <a href="#" class="text-gray">123-456-789</a> </li>
            <li class="font-14 mb-5"> <i class="fa fa-clock-o text-theme-colored"></i> Mon-Fri 8:00 to 2:00 </li>
            <li class="font-14 mb-5"> <i class="fa fa-envelope-o text-theme-colored"></i> <a href="#" class="text-gray">contact@yourdomain.com</a> </li>
          </ul>      
        </div>
        <div class="widget">
          <ul class="styled-icons icon-dark icon-theme-colored icon-sm">
            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
          </ul>
        </div>
        <p>Copyright &copy;2016 ThemeMascot</p>
      </div>
    </div>
  </div>
  <div id="wrapper" class="clearfix">
    <!-- preloader -->
    <div id="preloader">
      <div id="spinner">
        <div class="preloader-dot-loading">
          <div class="cssload-loading"><i></i><i></i><i></i><i></i></div>
        </div>
      </div>
      <div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>
    </div>

    <!-- Header -->
    <header class="header">
      <div class="header-nav">
        <div class="header-nav-wrapper navbar-scrolltofixed bg-light">
          <div class="container">
            <nav id="menuzord" class="menuzord orange bg-light">
              <div class="pull-left" style="padding-right:1.2em !important; padding-top: 1em !important;">
                <img src="images/logo.png" alt="">
              </div>
              <ul class="menuzord-menu" style="margin-left:2em;">
                <li class="active"><a href="#home">Home</a>
                  <li><a href="#">Pages</a>
                    <ul class="dropdown">
                      <li><a href="page-become-a-volunteer.html">Become a Volunteer</a></li>
                      <li><a href="#">Shop <span class="label label-success">New</span></a>
                        <ul class="dropdown">
                          <li><a href="shop-category.html">Category</a></li>
                          <li><a href="shop-category-sidebar.html">Category Sidebar</a></li>
                          <li><a href="shop-product-details.html">Product Details</a></li>
                          <li><a href="shop-cart.html">Cart</a></li>
                          <li><a href="shop-checkout.html">Checkout</a></li>
                        </ul>
                      </li>
                      <li><a href="#">About</a>
                        <ul class="dropdown">
                          <li><a href="page-about1.html">About Style1</a></li>
                          <li><a href="page-about2.html">About Style2</a></li>
                          <li><a href="page-about3.html">About Style3</a></li>
                        </ul>
                      </li>
                      <li><a href="#">Services</a>
                        <ul class="dropdown">
                          <li><a href="page-services1.html">Services Style1</a></li>
                          <li><a href="page-services2.html">Services Style2</a></li>
                        </ul>
                      </li>
                      <li><a href="#">Gallery <span class="label label-warning">New</span></a>
                        <ul class="dropdown">
                          <li><a href="page-gallery-3col.html">3 Columns</a></li>
                          <li><a href="page-gallery-3col-only-image.html">3 Columns Only Image</a></li>
                          <li><a href="page-gallery-4col.html">4 Columns</a></li>
                          <li><a href="page-gallery-4col-only-image.html">4 Columns Only Image</a></li>
                          <li><a href="page-gallery-grid.html">Grids (2-10 Columns)</a></li>
                          <li><a href="page-gallery-grid-animation.html">Grids with Animation (2-10 Columns)</a></li>
                          <li><a href="page-gallery-3col-tiles.html">3 Columns Tiles</a></li>
                          <li><a href="page-gallery-4col-tiles.html">4 Columns Tiles</a></li>
                          <li><a href="page-gallery-masonry-tiles.html">Tiles (2-10 Columns)</a></li>
                          <li><a href="page-gallery-masonry-tiles-animation.html">Tiles with Animation (2-10 Columns)</a></li>
                          <li><a href="page-gallery-prettyphoto.html">Pretty Photo Gallery</a></li>
                        </ul>
                      </li>
                      <li><a href="#">FAQ</a>
                        <ul class="dropdown">
                          <li><a href="page-faq-style1.html">FAQ Style1</a></li>
                          <li><a href="page-faq-style2.html">FAQ Style2</a></li>
                          <li><a href="page-faq-style3.html">FAQ Style3</a></li>
                          <li><a href="page-faq-style4.html">FAQ Style4</a></li>
                        </ul>
                      </li>
                      <li><a href="#">Contact</a>
                        <ul class="dropdown">
                          <li><a href="page-contact1.html">Contact Style1</a></li>
                          <li><a href="page-contact2.html">Contact Style2</a></li>
                          <li><a href="page-contact3.html">Contact Style3</a></li>
                          <li><a href="page-contact4.html">Contact Style4</a></li>
                          <li><a href="page-contact5-with-multiple-marker.html">Contact 5 - Multiple Marker</a></li>
                          <li><a href="page-contact6-with-multiple-marker.html">Contact 6 - Multiple Marker</a></li>
                        </ul>
                      </li>
                      <li><a href="#">Calender</a>
                        <ul class="dropdown">
                          <li><a href="page-calender1.html">Calender Style1</a></li>
                          <li><a href="page-calender2.html">Calender Style2</a></li>
                        </ul>
                      </li>
                      <li><a href="#">Events</a>
                        <ul class="dropdown">
                          <li><a href="#">Events Calendar</a>
                            <ul class="dropdown">
                              <li><a href="events-calendar-style1.html">Calendar Style1</a></li>
                              <li><a href="events-calendar-style2.html">Calendar Style1</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Events Grid</a>
                            <ul class="dropdown">
                              <li><a href="events-grid-2column.html">Grid 2column</a></li>
                              <li><a href="events-grid-3column.html">Grid 3column</a></li>
                              <li><a href="events-grid-4column.html">Grid 4column</a></li>
                              <li><a href="events-grid-left-sidebar.html">Grid Left Sidebar</a></li>
                              <li><a href="events-grid-right-sidebar.html">Grid Right Sidebar</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Events List</a>
                            <ul class="dropdown">
                              <li><a href="events-list-left-sidebar.html">List Left Sidebar</a></li>
                              <li><a href="events-list-right-sidebar.html">List Right Sidebar</a></li>
                              <li><a href="events-list-no-sidebar.html">List No Sidebar</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Events Details</a>
                            <ul class="dropdown">
                              <li><a href="events-details-style1.html">Details Style1</a></li>
                              <li><a href="events-details-style2.html">Details Style2</a></li>
                              <li><a href="events-details-style3.html">Details Style3</a></li>
                            </ul>
                          </li>
                          <li><a href="events-table.html">Events Table</a></li>
                        </ul>
                      </li>
                      <li><a href="#">Causes</a>
                        <ul class="dropdown">
                          <li><a href="page-cause-list.html">Cause List</a></li>
                          <li><a href="page-cause-grid.html">Cause Grid</a></li>
                          <li><a href="page-cause-details.html">Cause Details</a></li>
                        </ul>
                      </li>
                      <li><a href="#">Job <span class="label label-success">New</span></a>
                        <ul class="dropdown">
                          <li><a href="job-list.html">Job List</a></li>
                          <li><a href="job-details-style1.html">Job Details Style1</a></li>
                          <li><a href="job-details-style2.html">Job Details Style2</a></li>
                        </ul>
                      </li>
                      <li><a href="#">Pricing</a>
                        <ul class="dropdown">
                          <li><a href="page-pricing1.html">Pricing Style1</a></li>
                          <li><a href="page-pricing2.html">Pricing Style2</a></li>
                        </ul>
                      </li>
                      <li><a href="page-about4.html">Page with Sidebar</a>
                        <ul class="dropdown">
                          <li><a href="page-sidebar-right.html">Page Right Sidebar</a></li>
                          <li><a href="page-sidebar-left.html">Page Left Sidebar</a></li>
                        </ul>
                      </li>
                      <li><a href="#">Page 404</a>
                        <ul class="dropdown">
                          <li><a href="page-404-style1.html">Style1</a></li>
                          <li><a href="page-404-style2.html">Style2</a></li>
                          <li><a href="page-404-style3.html">Style3</a></li>
                        </ul>
                      </li>
                      <li><a href="#">Under Construction</a>
                        <ul class="dropdown">
                          <li><a href="page-under-construction-style1.html">Style1</a></li>
                          <li><a href="page-under-construction-style2.html">Style2</a></li>
                          <li><a href="page-under-construction-style3.html">Style3</a></li>
                        </ul>
                      </li>
                      <li><a href="#">Coming Soon</a>
                        <ul class="dropdown">
                          <li><a href="page-coming-soon-style1.html">Style1</a></li>
                          <li><a href="page-coming-soon-style2.html">Style2</a></li>
                          <li><a href="page-coming-soon-style3.html">Style3</a></li>
                        </ul>
                      </li>
                    </ul>
                  </li>
                  <li><a href="#">Campaigns<span class="label label-warning">New</span></a>
                    <ul class="dropdown">
                      <li><a href="#">Boxed</a>
                        <ul class="dropdown">
                          <li><a href="#">Gutter</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-boxed-gutter-1-col.html">1 Column</a></li>
                              <li><a href="portfolio-boxed-gutter-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-boxed-gutter-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-boxed-gutter-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-boxed-gutter-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-boxed-gutter-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-boxed-gutter-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-boxed-gutter-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-boxed-gutter-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-boxed-gutter-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Gutter Less</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-boxed-1-col.html">1 Column</a></li>
                              <li><a href="portfolio-boxed-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-boxed-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-boxed-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-boxed-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-boxed-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-boxed-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-boxed-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-boxed-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-boxed-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Title - Gutter</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-boxed-title-gutter-1-col.html">1 Column</a></li>
                              <li><a href="portfolio-boxed-title-gutter-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-boxed-title-gutter-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-boxed-title-gutter-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-boxed-title-gutter-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-boxed-title-gutter-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-boxed-title-gutter-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-boxed-title-gutter-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-boxed-title-gutter-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-boxed-title-gutter-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Title - Gutter Less</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-boxed-title-1-col.html">1 Column</a></li>
                              <li><a href="portfolio-boxed-title-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-boxed-title-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-boxed-title-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-boxed-title-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-boxed-title-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-boxed-title-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-boxed-title-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-boxed-title-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-boxed-title-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                        </ul>
                      </li>
                      <li><a href="#">Wide</a>
                        <ul class="dropdown">
                          <li><a href="#">Gutter</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-wide-gutter-1-col.html">1 Column</a></li>
                              <li><a href="portfolio-wide-gutter-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-wide-gutter-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-wide-gutter-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-wide-gutter-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-wide-gutter-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-wide-gutter-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-wide-gutter-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-wide-gutter-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-wide-gutter-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Gutter Less</a>                        
                            <ul class="dropdown">
                              <li><a href="portfolio-wide-1-col.html">1 Column</a></li>
                              <li><a href="portfolio-wide-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-wide-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-wide-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-wide-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-wide-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-wide-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-wide-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-wide-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-wide-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Title - Gutter</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-wide-title-gutter-1-col.html">1 Column</a></li>
                              <li><a href="portfolio-wide-title-gutter-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-wide-title-gutter-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-wide-title-gutter-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-wide-title-gutter-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-wide-title-gutter-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-wide-title-gutter-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-wide-title-gutter-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-wide-title-gutter-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-wide-title-gutter-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Title - Gutter Less</a>                        
                            <ul class="dropdown">
                              <li><a href="portfolio-wide-title-1-col.html">1 Column</a></li>
                              <li><a href="portfolio-wide-title-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-wide-title-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-wide-title-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-wide-title-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-wide-title-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-wide-title-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-wide-title-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-wide-title-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-wide-title-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                        </ul>
                      </li>
                      <li><a href="#">Masonry Boxed</a>
                        <ul class="dropdown">
                          <li><a href="#">Gutter</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-masonry-boxed-gutter-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Gutter Less</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-masonry-boxed-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Title - Gutter</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-masonry-boxed-gutter-title-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-title-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-title-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-title-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-title-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-title-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-title-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-title-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-gutter-title-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Title - Gutter Less</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-masonry-boxed-title-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-title-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-title-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-title-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-title-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-title-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-title-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-title-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-masonry-boxed-title-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                        </ul>
                      </li>
                      <li><a href="#">Masonry Wide</a>
                        <ul class="dropdown">
                          <li><a href="#">Gutter</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-masonry-wide-gutter-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Gutter Less</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-masonry-wide-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Title - Title - Gutter</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-masonry-wide-gutter-title-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-title-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-title-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-title-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-title-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-title-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-title-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-title-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-gutter-title-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Title - Title - Gutter Less</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-masonry-wide-title-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-title-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-title-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-title-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-title-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-title-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-title-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-title-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-masonry-wide-title-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                        </ul>
                      </li>
                      <li><a href="#">Tiles Boxed</a>
                        <ul class="dropdown">
                          <li><a href="#">Gutter</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-tiles-boxed-gutter-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-gutter-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-gutter-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-gutter-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-gutter-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-gutter-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-gutter-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-gutter-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-gutter-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Gutter Less</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-tiles-boxed-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Title - Gutter</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-tiles-boxed-title-gutter-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-gutter-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-gutter-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-gutter-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-gutter-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-gutter-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-gutter-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-gutter-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-gutter-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Title - Gutter Less</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-tiles-boxed-title-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-tiles-boxed-title-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                        </ul>
                      </li>
                      <li><a href="#">Tiles Wide</a>
                        <ul class="dropdown">
                          <li><a href="#">Gutter</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-tiles-wide-gutter-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-gutter-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-gutter-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-gutter-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-gutter-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-gutter-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-gutter-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-gutter-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-gutter-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Gutter Less</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-tiles-wide-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Title - Gutter</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-tiles-wide-title-gutter-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-gutter-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-gutter-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-gutter-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-gutter-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-gutter-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-gutter-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-gutter-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-gutter-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                          <li><a href="#">Title - Gutter Less</a>
                            <ul class="dropdown">
                              <li><a href="portfolio-tiles-wide-title-2-col.html">2 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-3-col.html">3 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-4-col.html">4 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-5-col.html">5 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-6-col.html">6 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-7-col.html">7 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-8-col.html">8 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-9-col.html">9 Columns</a></li>
                              <li><a href="portfolio-tiles-wide-title-10-col.html">10 Columns</a></li>
                            </ul>
                          </li>
                        </ul>
                      </li>
                      <li><a href="#">Loading Styles</a>
                        <ul class="dropdown">
                          <li><a href="portfolio-extra-infinity-scroll.html">Infinity Scroll</a></li>
                          <li><a href="portfolio-extra-infinity-scroll-lazyload.html">Infinity Scroll Lazyload</a></li>
                          <li><a href="portfolio-extra-pagination.html">Pagination</a></li>
                          <li><a href="portfolio-extra-jquery-pagination.html">Pagination Jquery</a></li>
                        </ul>
                      </li>
                      <li><a href="#">Single</a>
                        <ul class="dropdown">
                          <li><a href="portfolio-details-image.html">With - Image</a></li>
                          <li><a href="portfolio-details-image-gallery.html">With - Image Gallery</a></li>
                          <li><a href="portfolio-details-video-gallery.html">With - Video Gallery</a></li>
                        </ul>
                      </li>
                    </ul>
                  </li>
                  <li><a href="#home">Something</a>
                    <ul class="dropdown">
                      <li><a href="page-volunteer-4column.html">Volunteer 4column</a></li>
                      <li><a href="page-volunteer-3column.html">Volunteer 3column</a></li>
                      <li><a href="page-volunteer-2column.html">Volunteer 2column</a></li>
                      <li><a href="page-volunteer-details.html">Volunteer Details</a></li>
                    </ul>
                  </li>
                  <li><a href="javascript:void(0)">Blog</a>
                    <div class="megamenu">
                      <div class="megamenu-row">
                        <div class="col3">
                          <ul class="list-unstyled list-dashed">
                            <li>
                              <h5 class="pl-10"><strong>Classic:</strong></h5>
                            </li>
                            <li><a href="blog-classic-right-sidebar.html">Right Sidebar</a></li>
                            <li><a href="blog-classic-left-sidebar.html">Left Sidebar</a></li>
                            <li><a href="blog-classic-both-sidebar.html">Both Sidebar</a></li>
                            <li><a href="blog-classic-no-sidebar.html">No Sidebar</a></li>
                            <li><a href="blog-classic-small-thumbs.html">Small Thumbs</a></li>
                            <li>
                              <h6 class="pl-10"><strong>Extra:</strong></h6>
                            </li>
                            <li><a href="blog-timeline.html">Timeline</a></li>
                            <li><a href="blog-timeline-masonry.html">Timeline Masonry</a></li>
                            <li><a href="blog-extra-infinity-scroll.html">Infinity Scroll</a></li>
                            <li><a href="blog-extra-infinity-scroll-lazyload.html">Infinity Scroll + Lazyload</a></li>
                          </ul>
                        </div>
                        <div class="col3">
                          <ul class="list-unstyled list-dashed">
                            <li>
                              <h5 class="pl-10"><strong>Grid:</strong></h5>
                            </li>
                            <li><a href="blog-grid-2-column.html">2 Columns</a></li>
                            <li><a href="blog-grid-3-column.html">3 Columns</a></li>
                            <li><a href="blog-grid-4-column.html">4 Columns</a></li>
                            <li>
                              <h6 class="text-black font-weight-600 pl-10">Full Width:</h6>
                            </li>
                            <li><a href="blog-grid-width-2-column.html">2 Columns</a></li>
                            <li><a href="blog-grid-width-3-column.html">3 Columns</a></li>
                            <li><a href="blog-grid-width-4-column.html">4 Columns</a></li>
                          </ul>
                        </div>
                        <div class="col3">
                          <ul class="list-unstyled list-dashed">
                            <li>
                              <h5 class="pl-10"><strong>Masonry:</strong></h5>
                            </li>
                            <li><a href="blog-masonry-2-column.html">2 Columns</a></li>
                            <li><a href="blog-masonry-3-column.html">3 Columns</a></li>
                            <li><a href="blog-masonry-4-column.html">4 Columns</a></li>
                            <li>
                              <h6 class="text-black font-weight-600 pl-10">Full Width:</h6>
                            </li>
                            <li><a href="blog-masonry-width-2-column.html">2 Columns</a></li>
                            <li><a href="blog-masonry-width-3-column.html">3 Columns</a></li>
                            <li><a href="blog-masonry-width-4-column.html">4 Columns</a></li>
                          </ul>
                        </div>
                        <div class="col3">
                          <ul class="list-unstyled list-dashed">
                            <li>
                              <h5 class="pl-10"><strong>Single:</strong></h5>
                            </li>
                            <li><a href="blog-single-right-sidebar.html">Right Sidebar</a></li>
                            <li><a href="blog-single-left-sidebar.html">Left Sidebar</a></li>
                            <li><a href="blog-single-both-sidebar.html">Both Sidebar</a></li>
                            <li><a href="blog-single-no-sidebar.html">No Sidebar</a></li>
                            <li>
                              <h6 class="text-black font-weight-600 pl-10">Comments Plugins:</h6>
                            </li>
                            <li><a href="blog-single-facebook-comments.html#comments">Facebook Comments</a></li>
                            <li><a href="blog-single-disqus-comments.html#comments">Disqus Comments</a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </li>
                  <li><a href="javascript:void(0)">Something</a>
                    <div class="megamenu">
                      <div class="megamenu-row">
                        <div class="col3">
                          <ul class="list-unstyled list-dashed">
                            <li>
                              <h5 class="pl-10"><strong>Quick Links:</strong></h5>
                            </li>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Donor Privacy Policy</a></li>
                            <li><a href="#">Disclaimer</a></li>
                            <li><a href="#">Terms of Use</a></li>
                            <li><a href="#">Copyright Notice</a></li>
                            <li><a href="#">Media Center</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Donor Privacy Policy</a></li>
                          </ul>
                        </div>
                        <div class="col5">
                          <h5 class=""><strong>Featured News:</strong></h5>
                          <article class="post clearfix">
                            <div class="entry-header">
                              <div class="post-thumb"> <img class="img-responsive" src="http://placehold.it/360x220" alt=""> </div>
                              <h4 class="entry-title"><a href="#">Bankruptcy Rights Proceedings</a></h4>
                            </div>
                            <div class="entry-content">
                              <p class="">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna et sed aliqua</p>
                              <a class="btn btn-default btn-xs" href="#">read more..</a> </div>
                            </article>
                          </div>
                          <div class="col4">
                            <h5 class=""><strong>Latest News:</strong></h5>
                            <div class="list-dashed">
                              <article class="post media-post clearfix pb-0 mb-10"> <a href="#" class="post-thumb"><img alt="" src="http://placehold.it/75x75"></a>
                                <div class="post-right">
                                  <h5 class="post-title mt-0"><a href="#">Bankruptcy Rights Proceedings</a></h5>
                                  <p>Oct 23, 2015</p>
                                </div>
                              </article>
                              <article class="post media-post clearfix pb-0 mb-10"> <a href="#" class="post-thumb"><img alt="" src="http://placehold.it/75x75"></a>
                                <div class="post-right">
                                  <h5 class="post-title mt-0"><a href="#">Assertive and Persistent Advocacy</a></h5>
                                  <p>Jun 23, 2015</p>
                                </div>
                              </article>
                              <article class="post media-post clearfix pb-0 mb-10"> <a href="#" class="post-thumb"><img alt="" src="http://placehold.it/75x75"></a>
                                <div class="post-right">
                                  <h5 class="post-title mt-0"><a href="#">Government Contracts Procurement</a></h5>
                                  <p>Apr 15, 2015</p>
                                </div>
                              </article>
                              <article class="post media-post clearfix pb-0 mb-10"> <a href="#" class="post-thumb"><img alt="" src="http://placehold.it/75x75"></a>
                                <div class="post-right">
                                  <h5 class="post-title mt-0"><a href="#">Criminal Defence Advocacy</a></h5>
                                  <p>Mar 08, 2015</p>
                                </div>
                              </article>
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                  </ul>
                  <ul class="pull-right hidden-sm hidden-xs">
                    <li>
                      <a class="btn btn-colored btn-flat btn-theme-colored mt-15" 
                      <?php
                      if(isset($_SESSION["Username"]) && isset($_SESSION["Password"])){
                        echo 'href="user_profile.php" > '.$row['name'];
                      }
                      else
                        echo 'href="login.php" > Login/Register';
                      ?>
                      </a>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>
      </header>
      </li></ul></nav></div></div></div>
      </header>

        <!-- Start main-content -->
        <div class="main-content">
          <!-- Section: home -->
          <section id="home" class="divider">
            <div class="container-fluid p-0">

              <!-- Slider Revolution Start -->
              <div class="rev_slider_wrapper">
                <div class="rev_slider" data-version="5.0">
                  <ul>
                    <!-- SLIDE 1 -->
                    <li data-index="rs-1" data-transition="random" data-slotamount="7"  data-easein="default" data-easeout="default" data-masterspeed="1000"  data-thumb="images/jamghat.JPG"  data-rotate="0"  data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off"  data-title="Intro" data-description="">
                      <!-- MAIN IMAGE -->
                      <img src="images/jamghat1.JPG"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-bgparallax="6" data-no-retina>
                      <!-- LAYERS -->

                      <!-- LAYER NR. 1 -->
                      <div class="tp-caption BigBold-Title tp-resizeme rs-parallaxlevel-0 text-uppercase"
                      id="rs-1-layer-1"

                      data-x="['left','left','left','left']" 
                      data-hoffset="['50','50','30','17']" 
                      data-y="['bottom','bottom','bottom','bottom']" 
                      data-voffset="['110','110','180','160']" 
                      data-fontsize="['105','100','70','60']"
                      data-lineheight="['100','90','60','60']"
                      data-width="['none','none','none','400']"
                      data-height="none"
                      data-whitespace="['nowrap','nowrap','nowrap','normal']"
                      data-transform_idle="o:1;"
                      data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:1500;e:Power3.easeInOut;" 
                      data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                      data-mask_in="x:0px;y:[100%];" 
                      data-mask_out="x:inherit;y:inherit;" 
                      data-start="500" 
                      data-splitin="none" 
                      data-splitout="none" 
                      data-basealign="slide" 
                      data-responsive_offset="on"
                      style="z-index: 6; white-space: nowrap;">Child <span class="text-theme-colored">Care</span>
                    </div>

                    <!-- LAYER NR. 2 -->
                    <div class="tp-caption BigBold-SubTitle tp-resizeme rs-parallaxlevel-0"
                    id="rs-1-layer-2"

                    data-x="['left','left','left','left']" 
                    data-hoffset="['55','55','33','20']" 
                    data-y="['bottom','bottom','bottom','bottom']" 
                    data-voffset="['40','1','74','58']" 
                    data-fontsize="['15','15','15','13']"
                    data-lineheight="['24','24','24','20']"
                    data-width="['410','410','410','280']"
                    data-height="['60','100','100','100']"
                    data-whitespace="normal"
                    data-transform_idle="o:1;"
                    data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:1500;e:Power3.easeInOut;" 
                    data-transform_out="y:50px;opacity:0;s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                    data-start="650" 
                    data-splitin="none" 
                    data-splitout="none" 
                    data-basealign="slide" 
                    data-responsive_offset="on"
                    style="z-index: 7; min-width: 410px; max-width: 410px; max-width: 60px; max-width: 60px; white-space: normal;">A Premium Revolution Slider Template for your Website Highlights & Multi-Media Content. 
                  </div>

                  <!-- LAYER NR. 3 -->
                  <div class="tp-caption btn btn-default btn-transparent btn-flat btn-lg pl-40 pr-40 rs-parallaxlevel-0"

                  id="rs-1-layer-3"
                  data-x="['left','left','left','left']" 
                  data-hoffset="['470','480','30','20']" 
                  data-y="['bottom','bottom','bottom','bottom']" 
                  data-voffset="['50','50','30','20']" 
                  data-width="none"
                  data-height="none"
                  data-whitespace="nowrap"
                  data-transform_idle="o:1;"
                  data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"
                  data-style_hover="c:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);cursor:pointer;"
                  data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:1500;e:Power3.easeInOut;" 
                  data-transform_out="y:50px;opacity:0;s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                  data-start="650" 
                  data-splitin="none" 
                  data-splitout="none" 
                  data-actions='[{"event":"click","action":"scrollbelow","offset":"px"}]'
                  data-basealign="slide" 
                  data-responsive_offset="on"
                  style="z-index: 8; white-space: nowrap;background-color:#ec2e90;outline:none;box-shadow:none;">DONATE NOW 
                </div>
              </li>

              <!-- SLIDE 2 -->
              <li data-index="rs-2" data-transition="random" data-slotamount="7"  data-easein="default" data-easeout="default" data-masterspeed="1000"  data-thumb="http://placehold.it/1920x1280"  data-rotate="0"  data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off"  data-title="Intro" data-description="">
                <!-- MAIN IMAGE -->
                <img src="images/hvi1.JPG"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-bgparallax="6" data-no-retina>
                <!-- LAYERS -->

                <!-- LAYER NR. 1 -->
                <div class="tp-caption BigBold-Title tp-resizeme rs-parallaxlevel-0 text-uppercase"
                id="rs-2-layer-1"

                data-x="['left','left','left','left']" 
                data-hoffset="['50','50','30','17']" 
                data-y="['bottom','bottom','bottom','bottom']" 
                data-voffset="['110','110','180','160']" 
                data-fontsize="['78']"
                data-lineheight="['60']"
                data-width="['none','none','none','400']"
                data-height="none"
                data-whitespace="['nowrap','nowrap','nowrap','normal']"
                data-transform_idle="o:1;"
                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:1500;e:Power3.easeInOut;" 
                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                data-mask_in="x:0px;y:[100%];" 
                data-mask_out="x:inherit;y:inherit;" 
                data-start="500" 
                data-splitin="none" 
                data-splitout="none" 
                data-basealign="slide" 
                data-responsive_offset="on"
                style="z-index: 6; white-space: nowrap;"><span class="text-theme-colored">SAVE</span> THE CHILD
              </div>

              <!-- LAYER NR. 2 -->
              <div class="tp-caption BigBold-SubTitle tp-resizeme rs-parallaxlevel-0"
              id="rs-2-layer-2"

              data-x="['left','left','left','left']" 
              data-hoffset="['55','55','33','20']" 
              data-y="['bottom','bottom','bottom','bottom']" 
              data-voffset="['40','1','74','58']" 
              data-fontsize="['15','15','15','13']"
              data-lineheight="['24','24','24','20']"
              data-width="['410','410','410','280']"
              data-height="['60','100','100','100']"
              data-whitespace="normal"
              data-transform_idle="o:1;"
              data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:1500;e:Power3.easeInOut;" 
              data-transform_out="y:50px;opacity:0;s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
              data-start="650" 
              data-splitin="none" 
              data-splitout="none" 
              data-basealign="slide" 
              data-responsive_offset="on"
              style="z-index: 7; min-width: 410px; max-width: 410px; max-width: 60px; max-width: 60px; white-space: normal;">A Premium Revolution Slider Template for your Website Highlights & Multi-Media Content. 
            </div>

            <!-- LAYER NR. 3 -->
            <div class="tp-caption btn btn-default btn-transparent btn-flat btn-lg pl-40 pr-40 rs-parallaxlevel-0"

            id="rs-2-layer-3"
            data-x="['left','left','left','left']" 
            data-hoffset="['470','480','30','20']" 
            data-y="['bottom','bottom','bottom','bottom']" 
            data-voffset="['50','50','30','20']" 
            data-width="none"
            data-height="none"
            data-whitespace="nowrap"
            data-transform_idle="o:1;"
            data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"
            data-style_hover="c:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);cursor:pointer;"
            data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:1500;e:Power3.easeInOut;" 
            data-transform_out="y:50px;opacity:0;s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
            data-start="650" 
            data-splitin="none" 
            data-splitout="none" 
            data-actions='[{"event":"click","action":"scrollbelow","offset":"px"}]'
            data-basealign="slide" 
            data-responsive_offset="on"
            style="z-index: 8; white-space: nowrap;background-color:#ec2e90;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;">DONATE NOW 
          </div>
        </li>

        <!-- SLIDE 3 -->
        <li data-index="rs-3" data-transition="random" data-slotamount="7"  data-easein="default" data-easeout="default" data-masterspeed="1000"  data-thumb="http://placehold.it/1920x1280"  data-rotate="0"  data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off"  data-title="Intro" data-description="">
          <!-- MAIN IMAGE -->
          <img src=""  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-bgparallax="6" data-no-retina>
          <!-- LAYERS -->

          <!-- LAYER NR. 1 -->
          <div class="tp-caption BigBold-Title tp-resizeme rs-parallaxlevel-0"
          id="rs-3-layer-1"

          data-x="['left','left','left','left']" 
          data-hoffset="['50','50','30','17']" 
          data-y="['bottom','bottom','bottom','bottom']" 
          data-voffset="['110','110','180','160']" 
          data-fontsize="['110','100','70','60']"
          data-lineheight="['100','90','60','60']"
          data-width="['none','none','none','400']"
          data-height="none"
          data-whitespace="['nowrap','nowrap','nowrap','normal']"
          data-transform_idle="o:1;"
          data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:1500;e:Power3.easeInOut;" 
          data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
          data-mask_in="x:0px;y:[100%];" 
          data-mask_out="x:inherit;y:inherit;" 
          data-start="500" 
          data-splitin="none" 
          data-splitout="none" 
          data-basealign="slide" 
          data-responsive_offset="on"
          style="z-index: 6; white-space: nowrap;"><span class="text-theme-colored">DONATE</span> US
        </div>

        <!-- LAYER NR. 2 -->
        <div class="tp-caption BigBold-SubTitle tp-resizeme rs-parallaxlevel-0"
        id="rs-3-layer-2"

        data-x="['left','left','left','left']" 
        data-hoffset="['55','55','33','20']" 
        data-y="['bottom','bottom','bottom','bottom']" 
        data-voffset="['40','1','74','58']" 
        data-fontsize="['15','15','15','13']"
        data-lineheight="['24','24','24','20']"
        data-width="['410','410','410','280']"
        data-height="['60','100','100','100']"
        data-whitespace="normal"
        data-transform_idle="o:1;"
        data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:1500;e:Power3.easeInOut;" 
        data-transform_out="y:50px;opacity:0;s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
        data-start="650" 
        data-splitin="none" 
        data-splitout="none" 
        data-basealign="slide" 
        data-responsive_offset="on"
        style="z-index: 7; min-width: 410px; max-width: 410px; max-width: 60px; max-width: 60px; white-space: normal;">A Premium Revolution Slider Template for your Website Highlights & Multi-Media Content. 
      </div>

      <!-- LAYER NR. 3 -->
      <div class="tp-caption btn btn-default btn-transparent btn-flat btn-lg pl-40 pr-40 rs-parallaxlevel-0"

      id="rs-3-layer-3"
      data-x="['left','left','left','left']" 
      data-hoffset="['470','480','30','20']" 
      data-y="['bottom','bottom','bottom','bottom']" 
      data-voffset="['50','50','30','20']" 
      data-width="none"
      data-height="none"
      data-whitespace="nowrap"
      data-transform_idle="o:1;"
      data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"
      data-style_hover="c:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);cursor:pointer;"
      data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:1500;e:Power3.easeInOut;" 
      data-transform_out="y:50px;opacity:0;s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
      data-start="650" 
      data-splitin="none" 
      data-splitout="none" 
      data-actions='[{"event":"click","action":"scrollbelow","offset":"px"}]'
      data-basealign="slide" 
      data-responsive_offset="on"
      style="z-index: 8; white-space: nowrap;background-color:#ec2e90;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;">DONATE NOW 
    </div>
  </li>
</ul>
</div><!-- end .rev_slider -->
</div>
<!-- end .rev_slider_wrapper -->
<script>
  $(document).ready(function(e) {
    $(".rev_slider").revolution({
      sliderType:"standard",
      sliderLayout: "auto",
      dottedOverlay: "none",
      delay: 5000,
      navigation: {
        keyboardNavigation: "off",
        keyboard_direction: "horizontal",
        mouseScrollNavigation: "off",
        onHoverStop: "off",
        touch: {
          touchenabled: "on",
          swipe_threshold: 75,
          swipe_min_touches: 1,
          swipe_direction: "horizontal",
          drag_block_vertical: false
        },
        arrows: {
          style: "gyges",
          enable: true,
          hide_onmobile: false,
          hide_onleave: true,
          hide_delay: 200,
          hide_delay_mobile: 1200,
          tmp: '',
          left: {
            h_align: "left",
            v_align: "center",
            h_offset: 0,
            v_offset: 0
          },
          right: {
            h_align: "right",
            v_align: "center",
            h_offset: 0,
            v_offset: 0
          }
        },
        bullets: {
          enable:true,
          hide_onmobile:true,
          hide_under:960,
          style:"zeus",
          hide_onleave:false,
          direction:"horizontal",
          h_align:"right",
          v_align:"bottom",
          h_offset:80,
          v_offset:50,
          space:5,
          tmp:'<span class="tp-bullet-image"></span><span class="tp-bullet-imageoverlay"></span><span class="tp-bullet-title">{{title}}</span>'
        }
      },
      responsiveLevels: [1240, 1024, 778, 480],
      visibilityLevels: [1240, 1024, 778, 480],
      gridwidth: [1170, 1024, 778, 480],
      gridheight: [550, 768, 960, 720],
      lazyType: "none",
      parallax: {
        origo: "slidercenter",
        speed: 1000,
        levels: [5, 10, 15, 20, 25, 30, 35, 40, 45, 46, 47, 48, 49, 50, 100, 55],
        type: "scroll"
      },
      shadow: 0,
      spinner: "off",
      stopLoop: "on",
      stopAfterLoops: 0,
      stopAtSlide: -1,
      shuffle: "off",
      autoHeight: "off",
      fullScreenAutoWidth: "off",
      fullScreenAlignForce: "off",
      fullScreenOffsetContainer: "",
      fullScreenOffset: "0",
      hideThumbsOnMobile: "off",
      hideSliderAtLimit: 0,
      hideCaptionAtLimit: 0,
      hideAllCaptionAtLilmit: 0,
      debugMode: false,
      fallbacks: {
        simplifyAll: "off",
        nextSlideOnWindowFocus: "off",
        disableFocusListener: false,
      }
    });
  });
</script>
<!-- Slider Revolution Ends -->

</div>
</section>

<!-- Section: featured project -->
<section class="bg-lightest">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-8 wow fadeInLeft animation-delay6">
        <h4 class="text-uppercase line-bottom mt-0">Featured Project</h4>
        <div class="featured-project-carousel owl-nav-top">
          <div class="item">
            <div class="causes bg-lighter box-hover-effect effect1 sm-maxwidth500 mb-sm-30">
              <div class="thumb">
                <img class="img-fullwidth" alt="" src="images/rose.JPG">
              </div>
              <div class="progress-item mt-0">
                <div class="progress mb-0">
                  <div class="progress-bar" data-percent="85"></div>
                </div>
              </div>
              <div class="causes-details clearfix border-bottom p-15 pt-10">
                <p class="mb-10 mt-5"><span class="text-uppercase text-theme-colored"><strong>Rose:</strong></span>  To hire a full-time faculty and 2 mobilization resources.</p>
                <div class="donate-details">
                 <a class="btn btn-dark btn-theme-colored btn-flat btn-sm pull-left mt-10" href="#">Donate</a>
                 <ul class="pull-right list-inline mt-15">
                   <li>Raised: &#8377; 1890</li>
                   <li>Goal: &#8377; 2500</li>
                 </ul>
               </div>
             </div>
           </div>
         </div>
         <div class="item">
          <div class="causes bg-lighter box-hover-effect effect1 sm-maxwidth500 mb-sm-30">
            <div class="thumb">
              <img class="img-fullwidth" alt="" src="http://placehold.it/360x195">
            </div>
            <div class="progress-item mt-0">
              <div class="progress mb-0">
                <div class="progress-bar" data-percent="85"></div>
              </div>
            </div>
            <div class="causes-details clearfix border-bottom p-15 pt-10">
              <p class="mb-10 mt-5"><span class="text-uppercase text-theme-colored"><strong>Charity Hospital:</strong></span> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium quos aspernatur cupiditate commodi sunt illo.</p>
              <div class="donate-details">
               <a class="btn btn-dark btn-theme-colored btn-flat btn-sm pull-left mt-10" href="#">Donate</a>
               <ul class="pull-right list-inline mt-15">
                 <li>Raised: $1890</li>
                 <li>Goal: $2500</li>
               </ul>
             </div>
           </div>
         </div>
       </div>
       <div class="item">
        <div class="causes bg-lighter box-hover-effect effect1 sm-maxwidth500 mb-sm-30">
          <div class="thumb">
            <img class="img-fullwidth" alt="" src="http://placehold.it/360x195">
          </div>
          <div class="progress-item mt-0">
            <div class="progress mb-0">
              <div class="progress-bar" data-percent="85"></div>
            </div>
          </div>
          <div class="causes-details clearfix border-bottom p-15 pt-10">
            <p class="mb-10 mt-5"><span class="text-uppercase text-theme-colored"><strong>Charity Hospital:</strong></span> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium quos aspernatur cupiditate commodi sunt illo.</p>
            <div class="donate-details">
             <a class="btn btn-dark btn-theme-colored btn-flat btn-sm pull-left mt-10" href="#">Donate</a>
             <ul class="pull-right list-inline mt-15">
               <li>Raised: $1890</li>
               <li>Goal: $2500</li>
             </ul>
           </div>
         </div>
       </div>
     </div>
   </div>
 </div>
<div class="col-sm-12 col-md-4 wow fadeInRight animation-delay6">
  <h4 class="text-uppercase line-bottom mt-0">Other Campaings</h4>
  <div class="bxslider bx-nav-top">
    <div class="event media sm-maxwidth400 p-15 mt-0 mb-15">
      <div class="row">
        <div class="col-xs-3 p-0">
          <div class="thumb pl-15">
            <img alt="..." src="http://placehold.it/75x75" class="media-object">
          </div>
        </div>
        <div class="col-xs-6 p-0 pl-15">
          <div class="event-content">
            <h5 class="media-heading text-uppercase"><a href="#">Sports and Education for a better future!</a></h5>
            <ul>
              <li>Needs around 6lacs for help in building a classroom and for a water purifier</li>
              <li> <i class="fa fa-map-marker"></i>Hockey Village India</li>
            </ul>                    
          </div>                
        </div>
        <div class="col-xs-3 pr-0">
          <div class="event-date text-center">
            <ul>
              <li class="font-36 text-theme-colored font-weight-700"> &#8377;</li>
              <li class="font-20 text-center text-uppercase"> 40000</li>
            </ul>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>
</div>
</div>
</section>

<!-- Section: Causes -->
<section> 
  <div class="container pb-80">
    <div class="section-title text-center">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <h3 class="text-uppercase mt-0">Our Causes</h3>
          <div class="title-icon">
            <i class="flaticon-charity-hand-holding-a-heart"></i>
          </div>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem autem<br> voluptatem obcaecati!</p>
        </div>
      </div>
    </div>
    <div class="row mtli-row-clearfix">
      <div class="col-sm-6 col-md-3 col-lg-3">
        <div class="causes bg-lighter box-hover-effect effect1 maxwidth500 mb-sm-30">
          <div class="thumb">
            <img class="img-fullwidth" alt="" src="images/placeholder.jpg">
          </div>
          <div class="progress-item mt-0">
            <div class="progress mb-0">
              <div class="progress-bar" data-percent="84"></div>
            </div>
          </div>
          <div class="causes-details clearfix border-bottom p-15 pt-10">
            <h5><a href="#">Sponsor a child today</a></h5>
            <p>Lorem ipsum dolor sit amet, consect adipisicing elit. Praesent quos sit.</p>
            <ul class="list-inline clearfix mt-20">
              <li class="pull-left pr-0">Raised: $1890</li>
              <li class="text-theme-colored pull-right pr-0">Goal: $2500</li>
            </ul>
            <div class="mt-10">
             <a class="btn btn-dark btn-theme-colored btn-flat btn-sm pull-left mt-10" href="#">Donate</a>
             <div class="pull-right mt-15"><i class="fa fa-heart-o text-theme-colored"></i> 89 Donors</div>
           </div>
         </div>
       </div>
     </div>
     <div class="col-sm-6 col-md-3 col-lg-3">
      <div class="causes bg-lighter box-hover-effect effect1 maxwidth500 mb-sm-30">
        <div class="thumb">
          <img class="img-fullwidth" alt="" src="images/placeholder2.jpg">
        </div>
        <div class="progress-item mt-0">
          <div class="progress mb-0">
            <div class="progress-bar" data-percent="85"></div>
          </div>
        </div>
        <div class="causes-details clearfix border-bottom p-15 pt-10">
          <h5><a href="#">Sponsor a campaign today</a></h5>
          <p>Lorem ipsum dolor sit amet, consect adipisicing elit. Praesent quos sit.</p>
          <ul class="list-inline clearfix mt-20">
            <li class="pull-left pr-0">Raised: $1890</li>
            <li class="text-theme-colored pull-right pr-0">Goal: $2500</li>
          </ul>
          <div class="mt-10">
           <a class="btn btn-dark btn-theme-colored btn-flat btn-sm pull-left mt-10" href="#">Donate</a>
           <div class="pull-right mt-15"><i class="fa fa-heart-o text-theme-colored"></i> 89 Donors</div>
         </div>
       </div>
     </div>
   </div>
   <div class="col-sm-6 col-md-3 col-lg-3">
    <div class="causes bg-lighter box-hover-effect effect1 maxwidth500 mb-sm-30">
      <div class="thumb">
        <img class="img-fullwidth" alt="" src="images/placeholder4.jpg">
      </div>
      <div class="progress-item mt-0">
        <div class="progress mb-0">
          <div class="progress-bar" data-percent="86"></div>
        </div>
      </div>
      <div class="causes-details clearfix border-bottom p-15 pt-10">
        <h5><a href="#">Sponsor a campaign today</a></h5>
        <p>Lorem ipsum dolor sit amet, consect adipisicing elit. Praesent quos sit.</p>
        <ul class="list-inline clearfix mt-20">
          <li class="pull-left pr-0">Raised: $1890</li>
          <li class="text-theme-colored pull-right pr-0">Goal: $2500</li>
        </ul>
        <div class="mt-10">
         <a class="btn btn-dark btn-theme-colored btn-flat btn-sm pull-left mt-10" href="#">Donate</a>
         <div class="pull-right mt-15"><i class="fa fa-heart-o text-theme-colored"></i> 89 Donors</div>
       </div>
     </div>
   </div>
 </div>
 <div class="col-sm-6 col-md-3 col-lg-3">
  <div class="causes bg-lighter box-hover-effect effect1 maxwidth500 mb-sm-30">
    <div class="thumb">
      <img class="img-fullwidth" alt="" src="images/placeholder3.jpg">
    </div>
    <div class="progress-item mt-0">
      <div class="progress mb-0">
        <div class="progress-bar" data-percent="87"></div>
      </div>
    </div>
    <div class="causes-details clearfix border-bottom p-15 pt-10">
      <h5><a href="#">Sponsor a campaign today</a></h5>
      <p>Lorem ipsum dolor sit amet, consect adipisicing elit. Praesent quos sit.</p>
      <ul class="list-inline clearfix mt-20">
        <li class="pull-left pr-0">Raised: $1890</li>
        <li class="text-theme-colored pull-right pr-0">Goal: $2500</li>
      </ul>
      <div class="mt-10">
       <a class="btn btn-dark btn-theme-colored btn-flat btn-sm pull-left mt-10" href="#">Donate</a>
       <div class="pull-right mt-15"><i class="fa fa-heart-o text-theme-colored"></i> 89 Donors</div>
     </div>
   </div>
 </div>
</div>
</div>
</div>
</section>

<!-- divider: Donate Now -->
<section id="donate-now" class="divider"  data-bg-img="images/bg.JPG">
  <div class="container pt-0 pb-0">
    <div class="row">
      <div class="col-md-7">
        <div class="bg-light-transparent p-40">
          <h4 class="text-uppercase line-bottom">Make a Donation Now!</h4>

          <!-- Paypal Both Onetime/Recurring Form Starts -->
          <form action="donate/pay.php" method="POST" accept-charset="utf-8">
            <div class="row">


              <div class="col-md-12">
                <div class="form-group mb-20">
                  <label><strong>Payment Type</strong></label> <br>
                  <label class="radio-inline">
                    <input type="radio" checked="" value="one_time" name="payment_type"> 
                    One Time
                  </label>
                  <label class="radio-inline">
                    <input type="radio" value="recurring" name="payment_type"> 
                    Recurring
                  </label>
                </div>
              </div>

              <div class="col-sm-12" id="donation_type_choice">
                <div class="form-group mb-20">
                  <label><strong>Donation Type</strong></label>
                  <div class="radio mt-5">
                    <label class="radio-inline">
                      <input type="radio" value="D" name="t3" checked="">
                      Daily</label>
                      <label class="radio-inline">
                        <input type="radio" value="W" name="t3">
                        Weekly</label>
                        <label class="radio-inline">
                          <input type="radio" value="M" name="t3">
                          Monthly</label>
                          <label class="radio-inline">
                            <input type="radio" value="Y" name="t3">
                            Yearly</label>
                          </div>
                        </div>
                      </div>

                      <div class="col-sm-12">
                        <div class="form-group mb-20">
                          <label><strong>I Want to Donate for</strong></label>
                          <select name="camp_id" id="camp_id" class="form-control">
                          <?php                   
                        for($i=0; $row2 = $camp_list->fetch(); $i++){
                          ?>
                            <option value="<?php echo $row2['camp_id'] ?>"><?php echo $row2['camp_name'] ?></option>
                            <?php } ?>
                          </select>
                        </div>
                      </div>

                      <div class="col-sm-12">
                        <div class="form-group mb-20">
                          <label><strong>Currency</strong></label>
                          <select name="currency_code" class="form-control">                            
                            <option value="INR" selected="selected">INR - Indian Rupee</option>                            
                          </select>
                        </div>
                      </div>

                      <div class="col-sm-12">
                        <div class="form-group mb-20">
                          <label><strong>How much do you want to donate?</strong></label>
                          <select name="donation_amt" id="donation_amt" class="form-control">
                            <option value="20">20</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                            <option value="200">200</option>
                            <option value="500">500</option>
                            </select>
                            <!--option value="other">Other Amount</option>
                          </select>
                          <div id="custom_other_amount">
                            <label><strong>Custom Amount:</strong></label>
                          </div-->
                        </div>
                      </div>

                      <div class="col-sm-12">
                        <div class="form-group mb-20">
                          <button type="submit" class="btn btn-flat btn-dark btn-theme-colored mt-10 pl-30 pr-30" data-loading-text="Please wait...">Donate Now</button>
                        </div>
                      </div>
                    </div>

                  </form>

                  <!-- Script for Donation Form Custom Amount -->
                  <script type="text/javascript">
                    $(document).ready(function(e) {
                      var $donation_form = $("#paypal_donate_form_onetime_recurring");
                  //toggle custom amount
                  var $custom_other_amount = $donation_form.find("#custom_other_amount");
                  $custom_other_amount.hide();
                  $donation_form.find("select[name='amount']").change(function() {
                    var $this = $(this);
                    if ($this.val() == 'other') {
                      $custom_other_amount.show().append('<div class="input-group"><span class="input-group-addon">$</span> <input id="input_other_amount" type="text" name="amount" class="form-control" value="100"/></div>');
                    }
                    else{
                      $custom_other_amount.children( ".input-group" ).remove();
                      $custom_other_amount.hide();
                    }
                  });

                  //toggle donation_type_choice
                  var $donation_type_choice = $donation_form.find("#donation_type_choice");
                  $donation_type_choice.hide();
                  $("input[name='payment_type']").change(function() {
                    if (this.value == 'recurring') {
                      $donation_type_choice.show();
                    }
                    else {
                      $donation_type_choice.hide();
                    }
                  });


                  // submit form on click
                  $donation_form.on('submit', function(e){
                    $( "#paypal_donate_form-onetime" ).submit();
                    var item_name = $donation_form.find("select[name='item_name'] option:selected").val();
                    var currency_code = $donation_form.find("select[name='currency_code'] option:selected").val();
                    var amount = $donation_form.find("select[name='amount'] option:selected").val();
                    var t3 = $donation_form.find("input[name='t3']:checked").val();

                    if ( amount == 'other') {
                      amount = $donation_form.find("#input_other_amount").val();
                    }

                      // submit proper form now
                      if ( $("input[name='payment_type']:checked", $donation_form).val() == 'recurring' ) {
                        var recurring_form = $('#paypal_donate_form-recurring');

                        recurring_form.find("input[name='item_name']").val(item_name);
                        recurring_form.find("input[name='currency_code']").val(currency_code);
                        recurring_form.find("input[name='a3']").val(amount);
                        recurring_form.find("input[name='t3']").val(t3);

                        recurring_form.find("input[type='submit']").trigger('click');

                      } else if ( $("input[name='payment_type']:checked", $donation_form).val() == 'one_time' ) {
                        var onetime_form = $('#paypal_donate_form-onetime');

                        onetime_form.find("input[name='item_name']").val(item_name);
                        onetime_form.find("input[name='currency_code']").val(currency_code);
                        onetime_form.find("input[name='amount']").val(amount);

                        onetime_form.find("input[type='submit']").trigger('click');
                      }
                      return false;
                    });

                });
              </script>



              <!-- Paypal Onetime Form -->
              <form id="paypal_donate_form-onetime" class="hidden" action="https://www.paypal.com/cgi-bin/webscr" method="post">
                <input type="hidden" name="cmd" value="_donations">
                <input type="hidden" name="business" value="accounts@thememascot.com">

                <input type="hidden" name="item_name" value="Educate Children"> <!-- updated dynamically -->
                <input type="hidden" name="currency_code" value="USD"> <!-- updated dynamically -->
                <input type="hidden" name="amount" value="20"> <!-- updated dynamically -->

                <input type="hidden" name="no_shipping" value="1">
                <input type="hidden" name="cn" value="Comments...">
                <input type="hidden" name="tax" value="0">
                <input type="hidden" name="lc" value="US">
                <input type="hidden" name="bn" value="PP-DonationsBF">
                <input type="hidden" name="return" value="http://www.yoursite.com/thankyou.html">
                <input type="hidden" name="cancel_return" value="http://www.yoursite.com/paymentcancel.html">
                <input type="hidden" name="notify_url" value="http://www.yoursite.com/notifypayment.php">
                <input type="submit" name="submit">
              </form>
              
              <!-- Paypal Recurring Form -->
              <form id="paypal_donate_form-recurring" class="hidden" action="https://www.paypal.com/cgi-bin/webscr" method="post">
                <input type="hidden" name="cmd" value="_xclick-subscriptions">
                <input type="hidden" name="business" value="accounts@thememascot.com">

                <input type="hidden" name="item_name" value="Educate Children"> <!-- updated dynamically -->
                <input type="hidden" name="currency_code" value="USD"> <!-- updated dynamically -->
                <input type="hidden" name="a3" value="20"> <!-- updated dynamically -->
                <input type="hidden" name="t3" value="D"> <!-- updated dynamically -->


                <input type="hidden" name="p3" value="1">
                <input type="hidden" name="rm" value="2">
                <input type="hidden" name="src" value="1">
                <input type="hidden" name="sra" value="1">
                <input type="hidden" name="no_shipping" value="0">
                <input type="hidden" name="no_note" value="1">                     
                <input type="hidden" name="lc" value="US">
                <input type="hidden" name="bn" value="PP-DonationsBF">
                <input type="hidden" name="return" value="http://www.yoursite.com/thankyou.html">
                <input type="hidden" name="cancel_return" value="http://www.yoursite.com/paymentcancel.html">
                <input type="hidden" name="notify_url" value="http://www.yoursite.com/notifypayment.php">
                <input type="submit" name="submit">
              </form>
              <!-- Paypal Both Onetime/Recurring Form Ends -->

            </div>
          </div>
          <div class="col-md-5">
          </div>
        </div>
      </div>
    </section>
    
    
    
    

      <!-- Section: News -->
      <section>
        <div class="container pt-70">
          <div class="section-title text-center">
            <div class="row">
              <div class="col-md-8 col-md-offset-2">
                <h3 class="text-uppercase mt-0">Recent News</h3>
                <div class="title-icon">
                  <i class="flaticon-charity-hand-holding-a-heart"></i>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem autem<br> voluptatem obcaecati!</p>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="news-carousel owl-nav-top mb-sm-80" data-dots="true">
                <div class="item">
                  <article class="post clearfix maxwidth600 mb-sm-30 wow fadeInRight" data-wow-delay=".2s">
                    <div class="entry-header">
                      <div class="post-thumb thumb"> <img src="http://placehold.it/360x220" alt="" class="img-responsive img-fullwidth"> </div>
                      <div class="entry-meta meta-absolute text-center pl-15 pr-15">
                        <div class="display-table">
                          <div class="display-table-cell">
                            <ul>
                              <li><a class="text-white" href="#"><i class="fa fa-thumbs-o-up"></i> 265 <br> Likes</a></li>
                              <li class="mt-20"><a class="text-white" href="#"><i class="fa fa-comments-o"></i> 72 <br> comments</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="entry-content border-1px p-20">
                      <h5 class="entry-title mt-0 pt-0"><a href="#">Sponsor a child today</a></h5>
                      <p class="text-left mb-20 mt-15 font-13">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</p>
                      <a class="btn btn-flat btn-dark btn-theme-colored btn-sm pull-left" href="#">Read more</a>
                      <ul class="list-inline entry-date pull-right font-12 mt-5">
                        <li><a class="text-theme-colored" href="#">Admin |</a></li>
                        <li><span class="text-theme-colored">Nov 13, 2015</span></li>
                      </ul>
                      <div class="clearfix"></div>
                    </div>
                  </article>
                </div>
                <div class="item">
                  <article class="post clearfix maxwidth600 mb-sm-30 wow fadeInRight" data-wow-delay=".4s">
                    <div class="entry-header">
                      <div class="post-thumb thumb"> <img src="http://placehold.it/360x220" alt="" class="img-responsive img-fullwidth"> </div>
                      <div class="entry-meta meta-absolute text-center pl-15 pr-15">
                        <div class="display-table">
                          <div class="display-table-cell">
                            <ul>
                              <li><a class="text-white" href="#"><i class="fa fa-thumbs-o-up"></i> 265 <br> Likes</a></li>
                              <li class="mt-20"><a class="text-white" href="#"><i class="fa fa-comments-o"></i> 72 <br> comments</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="entry-content border-1px p-20">
                      <h5 class="entry-title mt-0 pt-0"><a href="#">Sponsor a child today</a></h5>
                      <p class="text-left mb-20 mt-15 font-13">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</p>
                      <a class="btn btn-flat btn-dark btn-theme-colored btn-sm pull-left" href="#">Read more</a>
                      <ul class="list-inline entry-date pull-right font-12 mt-5">
                        <li><a class="text-theme-colored" href="#">Admin |</a></li>
                        <li><span class="text-theme-colored">Nov 13, 2015</span></li>
                      </ul>
                      <div class="clearfix"></div>
                    </div>
                  </article>
                </div>
                <div class="item">
                  <article class="post clearfix maxwidth600 mb-sm-30 wow fadeInRight" data-wow-delay=".6s">
                    <div class="entry-header">
                      <div class="post-thumb thumb"> <img src="http://placehold.it/360x220" alt="" class="img-responsive img-fullwidth"> </div>
                      <div class="entry-meta meta-absolute text-center pl-15 pr-15">
                        <div class="display-table">
                          <div class="display-table-cell">
                            <ul>
                              <li><a class="text-white" href="#"><i class="fa fa-thumbs-o-up"></i> 265 <br> Likes</a></li>
                              <li class="mt-20"><a class="text-white" href="#"><i class="fa fa-comments-o"></i> 72 <br> comments</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="entry-content border-1px p-20">
                      <h5 class="entry-title mt-0 pt-0"><a href="#">Sponsor a child today</a></h5>
                      <p class="text-left mb-20 mt-15 font-13">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</p>
                      <a class="btn btn-flat btn-dark btn-theme-colored btn-sm pull-left" href="#">Read more</a>
                      <ul class="list-inline entry-date pull-right font-12 mt-5">
                        <li><a class="text-theme-colored" href="#">Admin |</a></li>
                        <li><span class="text-theme-colored">Nov 13, 2015</span></li>
                      </ul>
                      <div class="clearfix"></div>
                    </div>
                  </article>
                </div>
                <div class="item">
                  <article class="post clearfix maxwidth600 mb-sm-30">
                    <div class="entry-header">
                      <div class="post-thumb thumb"> <img src="http://placehold.it/360x220" alt="" class="img-responsive img-fullwidth"> </div>
                      <div class="entry-meta meta-absolute text-center pl-15 pr-15">
                        <div class="display-table">
                          <div class="display-table-cell">
                            <ul>
                              <li><a class="text-white" href="#"><i class="fa fa-thumbs-o-up"></i> 265 <br> Likes</a></li>
                              <li class="mt-20"><a class="text-white" href="#"><i class="fa fa-comments-o"></i> 72 <br> comments</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="entry-content border-1px p-20">
                      <h5 class="entry-title mt-0 pt-0"><a href="#">Sponsor a child today</a></h5>
                      <p class="text-left mb-20 mt-15 font-13">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</p>
                      <a class="btn btn-flat btn-dark btn-theme-colored btn-sm pull-left" href="#">Read more</a>
                      <ul class="list-inline entry-date pull-right font-12 mt-5">
                        <li><a class="text-theme-colored" href="#">Admin |</a></li>
                        <li><span class="text-theme-colored">Nov 13, 2015</span></li>
                      </ul>
                      <div class="clearfix"></div>
                    </div>
                  </article>
                </div>
                <div class="item">
                  <article class="post clearfix maxwidth600 mb-sm-30">
                    <div class="entry-header">
                      <div class="post-thumb thumb"> <img src="http://placehold.it/360x220" alt="" class="img-responsive img-fullwidth"> </div>
                      <div class="entry-meta meta-absolute text-center pl-15 pr-15">
                        <div class="display-table">
                          <div class="display-table-cell">
                            <ul>
                              <li><a class="text-white" href="#"><i class="fa fa-thumbs-o-up"></i> 265 <br> Likes</a></li>
                              <li class="mt-20"><a class="text-white" href="#"><i class="fa fa-comments-o"></i> 72 <br> comments</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="entry-content border-1px p-20">
                      <h5 class="entry-title mt-0 pt-0"><a href="#">Sponsor a child today</a></h5>
                      <p class="text-left mb-20 mt-15 font-13">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</p>
                      <a class="btn btn-flat btn-dark btn-theme-colored btn-sm pull-left" href="#">Read more</a>
                      <ul class="list-inline entry-date pull-right font-12 mt-5">
                        <li><a class="text-theme-colored" href="#">Admin |</a></li>
                        <li><span class="text-theme-colored">Nov 13, 2015</span></li>
                      </ul>
                      <div class="clearfix"></div>
                    </div>
                  </article>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    <!-- end main-content -->

    <!-- Footer -->
    <footer id="footer" class="footer pb-0" data-bg-img="images/footer-bg.png" data-bg-color="#25272e">
      <div class="container pb-20">
        <div class="row multi-row-clearfix">
          <div class="col-sm-6 col-md-3">
            <div class="widget dark"> <img alt="" src="images/logo.png">
              <p class="font-12 mt-20 mb-10">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
              quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
              consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
              cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
              proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
              <a class="text-gray font-12" href="#"><i class="fa fa-angle-double-right text-theme-colored"></i> Read more</a>
              <ul class="styled-icons icon-dark mt-20">
                <li class="wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay=".1s" data-wow-offset="10"><a href="#" data-bg-color="#3B5998"><i class="fa fa-facebook"></i></a></li>
                <li class="wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay=".2s" data-wow-offset="10"><a href="#" data-bg-color="#02B0E8"><i class="fa fa-twitter"></i></a></li>
                <li class="wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay=".3s" data-wow-offset="10"><a href="#" data-bg-color="#05A7E3"><i class="fa fa-skype"></i></a></li>
                <li class="wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay=".4s" data-wow-offset="10"><a href="#" data-bg-color="#A11312"><i class="fa fa-google-plus"></i></a></li>
                <li class="wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay=".5s" data-wow-offset="10"><a href="#" data-bg-color="#C22E2A"><i class="fa fa-youtube"></i></a></li>
              </ul>
            </div>
          </div>
          <div class="col-sm-6 col-md-3">
            <div class="widget dark">
              <h5 class="widget-title line-bottom">Projects</h5>
              <ul class="list-border list theme-colored angle-double-right">
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Donor Privacy Policy</a></li>
                <li><a href="#">Disclaimer</a></li>
                <li><a href="#">Terms of Use</a></li>
                <li><a href="#">Copyright Notice</a></li>
                <li><a href="#">Media Center</a></li>
              </ul>
            </div>
          </div>
          <div class="col-sm-6 col-md-3">
            <div class="widget dark">
              <h5 class="widget-title line-bottom">Quick Links</h5>
              <ul class="list-border list theme-colored angle-double-right">
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Donor Privacy Policy</a></li>
                <li><a href="#">Disclaimer</a></li>
                <li><a href="#">Terms of Use</a></li>
                <li><a href="#">Copyright Notice</a></li>
                <li><a href="#">Media Center</a></li>
              </ul>
            </div>
          </div>
          <div class="col-sm-6 col-md-3">
            <div class="widget dark">
              <h5 class="widget-title line-bottom">Quick Contact</h5>
              <ul class="list-border">
                <li><a href="#">+(012) 345 6789</a></li>
                <li><a href="#">hello@yourdomain.com</a></li>
                <li><a href="#" class="lineheight-20">121 King Street, Melbourne Victoria 3000, Australia</a></li>
              </ul>
              <p class="text-white mb-5 mt-15">Subscribe to our newsletter</p>
              <form id="footer-mailchimp-subscription-form" class="newsletter-form mt-10">
                <label class="display-block" for="mce-EMAIL"></label>
                <div class="input-group">
                  <input type="email" value="" name="EMAIL" placeholder="Your Email"  class="form-control" data-height="37px" id="mce-EMAIL">
                  <span class="input-group-btn">
                    <button type="submit" class="btn btn-colored btn-theme-colored m-0"><i class="fa fa-paper-plane-o text-white"></i></button>
                  </span>
                </div>
              </form>
              <!-- Mailchimp Subscription Form Validation-->
              <script type="text/javascript">
                $('#footer-mailchimp-subscription-form').ajaxChimp({
                  callback: mailChimpCallBack,
                  url: '//thememascot.us9.list-manage.com/subscribe/post?u=a01f440178e35febc8cf4e51f&amp;id=49d6d30e1e'
                });

                function mailChimpCallBack(resp) {
                  // Hide any previous response text
                  var $mailchimpform = $('#footer-mailchimp-subscription-form'),
                  $response = '';
                  $mailchimpform.children(".alert").remove();
                  if (resp.result === 'success') {
                    $response = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' + resp.msg + '</div>';
                  } else if (resp.result === 'error') {
                    $response = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' + resp.msg + '</div>';
                  }
                  $mailchimpform.prepend($response);
                }
              </script>
            </div>
          </div>
        </div>
      </div>
      <div class="container-fluid bg-theme-colored p-20">
        <div class="row text-center">
          <div class="col-md-12">
            <p class="text-white font-11 m-0">Copyright &copy;2017 Kodexlabs. All Rights Reserved</p>
          </div>
        </div>
      </div>
    </footer>
    <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
  </div>
  <!-- end wrapper -->

  <!-- Footer Scripts -->
  <!-- JS | Custom script for all pages -->
  <script src="js/custom.js"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  
      (Load Extensions only on Local File Systems ! 
      The following part can be removed on Server for On Demand Loading) -->
      <script type="text/javascript" src="js/revolution-slider/js/extensions/revolution.extension.actions.min.js"></script>
      <script type="text/javascript" src="js/revolution-slider/js/extensions/revolution.extension.carousel.min.js"></script>
      <script type="text/javascript" src="js/revolution-slider/js/extensions/revolution.extension.kenburn.min.js"></script>
      <script type="text/javascript" src="js/revolution-slider/js/extensions/revolution.extension.layeranimation.min.js"></script>
      <script type="text/javascript" src="js/revolution-slider/js/extensions/revolution.extension.migration.min.js"></script>
      <script type="text/javascript" src="js/revolution-slider/js/extensions/revolution.extension.navigation.min.js"></script>
      <script type="text/javascript" src="js/revolution-slider/js/extensions/revolution.extension.parallax.min.js"></script>
      <script type="text/javascript" src="js/revolution-slider/js/extensions/revolution.extension.slideanims.min.js"></script>
      <script type="text/javascript" src="js/revolution-slider/js/extensions/revolution.extension.video.min.js"></script>


    </body>
    </html>